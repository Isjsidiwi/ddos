const settings = {
  ownerName: 'Rizx DDOS', // Ganti dengan nama owner lu
  botToken: '8099921991:AAH14xHYUP_NCER2Y4goDZWBMcVzGL5AZFs', // Ganti dengan token bot Telegram lu
  owner: '6494670807', //OWNER user id
};

module.exports = settings;
